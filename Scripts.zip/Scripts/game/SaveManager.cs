using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

[Serializable]
public class SavedCell
{
    public int x;
    public int y;
}

[Serializable]
public class GameSaveData
{
    public int version = 1;
    public int worldSeed;
    public float playerX;
    public float playerY;
    public float playerZ;
    public int copper;
    public bool hasPickaxe;
    public List<SavedCell> minedCells = new List<SavedCell>();
}

// Put ONE SaveManager on an active GameObject in the gameplay scene.
// It restores the world before Testmapgen.Start() generates any chunks.
[DefaultExecutionOrder(-1000)]
public class SaveManager : MonoBehaviour
{
    public static SaveManager Instance { get; private set; }

    [Header("References")]
    [SerializeField] private Testmapgen world;
    [SerializeField] private PlayerInventory inventory;
    [SerializeField] private Transform player;

    [Header("Autosave")]
    [SerializeField] private bool autosaveEnabled = true;
    [Min(10f)] [SerializeField] private float autosaveInterval = 120f;

    private static int selectedSlot = 1;
    private static bool startNewGame = false;
    private float nextAutosave;
    private bool initialized;

    public static void SelectSlot(int slot, bool isNewGame)
    {
        selectedSlot = Mathf.Clamp(slot, 1, 3);
        startNewGame = isNewGame;
        PlayerPrefs.SetInt("LastSaveSlot", selectedSlot);
        PlayerPrefs.Save();
    }

    public static string GetSavePath(int slot)
    {
        return Path.Combine(Application.persistentDataPath,
            "mining_save_" + Mathf.Clamp(slot, 1, 3) + ".json");
    }

    public static bool SaveExists(int slot) => File.Exists(GetSavePath(slot));

    public static void DeleteSave(int slot)
    {
        string path = GetSavePath(slot);
        if (File.Exists(path)) File.Delete(path);
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        if (world == null) world = FindObjectOfType<Testmapgen>();
        if (inventory == null) inventory = FindObjectOfType<PlayerInventory>();
        if (player == null && inventory != null) player = inventory.transform;

        if (world == null || inventory == null || player == null)
        {
            Debug.LogError("SaveManager: assign World, Inventory and Player references.");
            enabled = false;
            return;
        }

        // The scene's default worldSeed is used for new games.
        // Existing games restore the seed before world generation starts.
        if (!startNewGame && SaveExists(selectedSlot))
        {
            try
            {
                GameSaveData data = JsonUtility.FromJson<GameSaveData>(
                    File.ReadAllText(GetSavePath(selectedSlot)));
                if (data == null || data.version != 1)
                    throw new Exception("Unsupported or empty save file");

                world.worldSeed = data.worldSeed;
                player.position = new Vector3(data.playerX, data.playerY, data.playerZ);
                inventory.RestoreInventory(data.copper, data.hasPickaxe);
                world.LoadMinedCells(data.minedCells);
                Debug.Log("Loaded save slot " + selectedSlot);
            }
            catch (Exception ex)
            {
                Debug.LogError("Could not load save slot " + selectedSlot + ": " + ex.Message);
                enabled = false; // Do not overwrite a failed/corrupted load.
                return;
            }
        }
        else
        {
            // New game: clear stale inventory values on the player prefab.
            inventory.RestoreInventory(0, false);
            world.LoadMinedCells(null);
        }
        startNewGame = false;
        initialized = true;
        nextAutosave = Time.unscaledTime + autosaveInterval;
    }

    private void Update()
    {
        if (!initialized || !autosaveEnabled || Time.timeScale == 0f) return;
        if (Time.unscaledTime >= nextAutosave)
        {
            SaveGame();
            nextAutosave = Time.unscaledTime + autosaveInterval;
        }
    }

    public void SaveGame()
    {
        if (!initialized) return;
        GameSaveData data = new GameSaveData
        {
            worldSeed = world.worldSeed,
            playerX = player.position.x,
            playerY = player.position.y,
            playerZ = player.position.z,
            copper = inventory.Copper,
            hasPickaxe = inventory.HasPickaxe,
            minedCells = world.GetMinedCells()
        };
        try
        {
            string path = GetSavePath(selectedSlot);
            string temp = path + ".tmp";
            File.WriteAllText(temp, JsonUtility.ToJson(data, true));
            // Replace the previous save only after writing the new file.
            File.Copy(temp, path, true);
            File.Delete(temp);
            PlayerPrefs.SetInt("LastSaveSlot", selectedSlot);
            PlayerPrefs.Save();
            Debug.Log("Saved slot " + selectedSlot + " to " + path);
        }
        catch (Exception ex)
        {
            Debug.LogError("Save failed: " + ex.Message);
        }
    }

    private void OnApplicationQuit()
    {
        if (initialized) SaveGame();
    }

    private void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }
}
