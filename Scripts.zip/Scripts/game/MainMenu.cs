
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    [SerializeField] private string gameSceneName = "GameScene";
    [SerializeField] private GameObject settingsPanel;

    // Assign these methods to New Game and Load buttons in the Inspector.
    public void NewGameSlot1() => StartSlot(1, true);
    public void NewGameSlot2() => StartSlot(2, true);
    public void NewGameSlot3() => StartSlot(3, true);
    public void LoadSlot1() => StartSlot(1, false);
    public void LoadSlot2() => StartSlot(2, false);
    public void LoadSlot3() => StartSlot(3, false);

    public void ContinueGame()
    {
        int slot = PlayerPrefs.GetInt("LastSaveSlot", 1);
        StartSlot(slot, false);
    }

    private void StartSlot(int slot, bool newGame)
    {
        if (!newGame && !SaveManager.SaveExists(slot))
        {
            Debug.LogWarning("Save slot " + slot + " is empty.");
            return;
        }
        // New Game overwrites the selected slot. Confirm in UI before calling.
        if (newGame) SaveManager.DeleteSave(slot);
        SaveManager.SelectSlot(slot, newGame);
        Time.timeScale = 1f;
        SceneManager.LoadScene(gameSceneName);
    }

    public void PlayGame()
    {
        // Existing Play button starts a new game in slot 1.
        // Change its OnClick to ContinueGame or a specific slot method if desired.
        StartSlot(1, true);
    }

    public void OpenSettings()
    {
        if (settingsPanel != null)
            settingsPanel.SetActive(true);
    }

    public void CloseSettings()
    {
        if (settingsPanel != null)
            settingsPanel.SetActive(false);
    }

    public void QuitGame()
    {
        Debug.Log("Quitting game...");
        Application.Quit();
    }
}
