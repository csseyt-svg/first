using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class GameSettings : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private Slider volumeSlider;
    [SerializeField] private Toggle fullscreenToggle;
    [SerializeField] private Toggle vsyncToggle;
    [SerializeField] private TMP_Dropdown resolutionDropdown;

    private readonly List<Resolution> resolutions = new List<Resolution>();
    private bool initializing;

    private void Start()
    {
        initializing = true;
        LoadAndApplySettings();
        SetupResolutions();

        if (volumeSlider != null) volumeSlider.onValueChanged.AddListener(SetVolume);
        if (fullscreenToggle != null) fullscreenToggle.onValueChanged.AddListener(SetFullscreen);
        if (vsyncToggle != null) vsyncToggle.onValueChanged.AddListener(SetVSync);
        if (resolutionDropdown != null) resolutionDropdown.onValueChanged.AddListener(SetResolution);
        initializing = false;
    }

    private void LoadAndApplySettings()
    {
        float volume = PlayerPrefs.GetFloat("MasterVolume", 0.75f);
        bool fullscreen = PlayerPrefs.GetInt("Fullscreen", Screen.fullScreen ? 1 : 0) == 1;
        bool vsync = PlayerPrefs.GetInt("VSync", QualitySettings.vSyncCount > 0 ? 1 : 0) == 1;

        AudioListener.volume = Mathf.Clamp01(volume);
        Screen.fullScreen = fullscreen;
        QualitySettings.vSyncCount = vsync ? 1 : 0;

        if (volumeSlider != null) volumeSlider.SetValueWithoutNotify(volume);
        if (fullscreenToggle != null) fullscreenToggle.SetIsOnWithoutNotify(fullscreen);
        if (vsyncToggle != null) vsyncToggle.SetIsOnWithoutNotify(vsync);
    }

    private void SetupResolutions()
    {
        if (resolutionDropdown == null) return;

        resolutions.Clear();
        List<string> options = new List<string>();
        int selected = 0;
        int savedWidth = PlayerPrefs.GetInt("ResolutionWidth", Screen.width);
        int savedHeight = PlayerPrefs.GetInt("ResolutionHeight", Screen.height);

        foreach (Resolution resolution in Screen.resolutions)
        {
            bool duplicate = false;
            foreach (Resolution existing in resolutions)
            {
                if (existing.width == resolution.width && existing.height == resolution.height)
                {
                    duplicate = true;
                    break;
                }
            }
            if (duplicate) continue;
            if (resolution.width < 640 || resolution.height < 480) continue;

            if (resolution.width == savedWidth && resolution.height == savedHeight)
                selected = resolutions.Count;
            resolutions.Add(resolution);
            options.Add(resolution.width + " x " + resolution.height);
        }

        resolutionDropdown.ClearOptions();
        resolutionDropdown.AddOptions(options);
        if (resolutions.Count == 0) return;
        resolutionDropdown.SetValueWithoutNotify(selected);
        resolutionDropdown.RefreshShownValue();

        if (PlayerPrefs.HasKey("ResolutionWidth") && PlayerPrefs.HasKey("ResolutionHeight"))
            Screen.SetResolution(resolutions[selected].width, resolutions[selected].height, Screen.fullScreen);
    }

    public void SetVolume(float value)
    {
        if (initializing) return;
        AudioListener.volume = Mathf.Clamp01(value);
        PlayerPrefs.SetFloat("MasterVolume", AudioListener.volume);
        PlayerPrefs.Save();
    }

    public void SetFullscreen(bool enabled)
    {
        if (initializing) return;
        Screen.fullScreen = enabled;
        PlayerPrefs.SetInt("Fullscreen", enabled ? 1 : 0);
        PlayerPrefs.Save();
    }

    public void SetVSync(bool enabled)
    {
        if (initializing) return;
        QualitySettings.vSyncCount = enabled ? 1 : 0;
        PlayerPrefs.SetInt("VSync", enabled ? 1 : 0);
        PlayerPrefs.Save();
    }

    public void SetResolution(int index)
    {
        if (initializing || index < 0 || index >= resolutions.Count) return;
        Resolution resolution = resolutions[index];
        Screen.SetResolution(resolution.width, resolution.height, Screen.fullScreen);
        PlayerPrefs.SetInt("ResolutionWidth", resolution.width);
        PlayerPrefs.SetInt("ResolutionHeight", resolution.height);
        PlayerPrefs.Save();
    }
}
