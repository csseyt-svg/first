using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    [Header("Health")]
    [Min(1)] public int maxHealth = 3;
    public int CurrentHealth { get; private set; }

    private bool isDead;

    private void Awake()
    {
        CurrentHealth = Mathf.Max(1, maxHealth);
    }

    public void TakeDamage(int damage)
    {
        if (isDead || damage <= 0) return;

        CurrentHealth = Mathf.Max(0, CurrentHealth - damage);
        if (CurrentHealth == 0) Die();
    }

    private void Die()
    {
        if (isDead) return;
        isDead = true;
        Destroy(gameObject);
    }
}
