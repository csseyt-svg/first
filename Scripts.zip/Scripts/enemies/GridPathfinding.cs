using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class GridPathfinding : MonoBehaviour
{
    public static GridPathfinding Instance { get; private set; }

    [Header("Tilemap Reference")]
    [SerializeField] private Tilemap wallTilemap;

    [Header("Search Settings")]
    [Min(100)] [SerializeField] private int maxSearchedNodes = 2000;
    [Tooltip("Additional clear tiles required around each path tile. 0 allows narrow one-tile corridors.")]
    [Range(0, 2)] [SerializeField] private int clearanceTiles = 0;

    [Header("Corner Clearance")]
    [Tooltip("Approximate radius of the enemy collider in world units. Start with 0.35 for a 1-unit tile.")]
    [Min(0f)] [SerializeField] private float enemyRadius = 0.35f;

    private static readonly Vector3Int[] Directions = {
        Vector3Int.right, Vector3Int.left, Vector3Int.up, Vector3Int.down
    };

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(this); return; }
        Instance = this;
    }

    private void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }

    public List<Vector3> FindPath(Vector3 startPos, Vector3 targetPos)
    {
        if (wallTilemap == null) { Debug.LogWarning("GridPathfinding: Assign Wall Tilemap.", this); return null; }

        Vector3Int start = wallTilemap.WorldToCell(startPos);
        Vector3Int goal = wallTilemap.WorldToCell(targetPos);
        start.z = 0;
        goal.z = 0;
        if (!IsWalkable(start)) return null;
        if (!IsWalkable(goal)) goal = FindNearbyWalkable(goal);
        if (!IsWalkable(goal)) return null;
        if (start == goal) return new List<Vector3>();

        var open = new List<Vector3Int> { start };
        var openLookup = new HashSet<Vector3Int> { start };
        var closed = new HashSet<Vector3Int>();
        var parents = new Dictionary<Vector3Int, Vector3Int>();
        var costs = new Dictionary<Vector3Int, int> { [start] = 0 };

        int searched = 0;
        while (open.Count > 0 && searched++ < maxSearchedNodes)
        {
            int bestIndex = 0;
            int bestScore = int.MaxValue;
            for (int i = 0; i < open.Count; i++)
            {
                Vector3Int node = open[i];
                int score = costs[node] + Manhattan(node, goal);
                if (score < bestScore) { bestScore = score; bestIndex = i; }
            }

            Vector3Int current = open[bestIndex];
            open.RemoveAt(bestIndex);
            openLookup.Remove(current);
            if (current == goal) return BuildPath(start, goal, parents);
            closed.Add(current);

            foreach (Vector3Int direction in Directions)
            {
                Vector3Int next = current + direction;
                if (closed.Contains(next) || !IsWalkable(next)) continue;
                int tentativeCost = costs[current] + 1;
                if (costs.TryGetValue(next, out int existing) && tentativeCost >= existing) continue;
                parents[next] = current;
                costs[next] = tentativeCost;
                if (openLookup.Add(next)) open.Add(next);
            }
        }
        return null;
    }

    private List<Vector3> BuildPath(Vector3Int start, Vector3Int goal, Dictionary<Vector3Int, Vector3Int> parents)
    {
        var result = new List<Vector3>();
        Vector3Int current = goal;
        while (current != start)
        {
            result.Add(wallTilemap.GetCellCenterWorld(current));
            if (!parents.TryGetValue(current, out current)) return null;
        }
        result.Reverse();
        return result;
    }

    private Vector3Int FindNearbyWalkable(Vector3Int center)
    {
        // Find the closest walkable target within two tiles, rather than choosing an arbitrary neighbor.
        for (int distance = 1; distance <= 2; distance++)
        {
            for (int dx = -distance; dx <= distance; dx++)
            {
                int dy = distance - Mathf.Abs(dx);
                Vector3Int a = center + new Vector3Int(dx, dy, 0);
                if (IsWalkable(a)) return a;
                if (dy != 0)
                {
                    Vector3Int b = center + new Vector3Int(dx, -dy, 0);
                    if (IsWalkable(b)) return b;
                }
            }
        }
        return center;
    }

    public bool IsWalkable(Vector3Int cell)
    {
        if (wallTilemap == null) return false;
        for (int x = -clearanceTiles; x <= clearanceTiles; x++)
        for (int y = -clearanceTiles; y <= clearanceTiles; y++)
            if (wallTilemap.HasTile(cell + new Vector3Int(x, y, 0))) return false;
        // A tile center is not safe if the enemy's body overlaps an adjacent wall.
        // Check the actual world-space wall cell bounds against a circle.
        Vector2 center = wallTilemap.GetCellCenterWorld(cell);
        Vector3 cellSize = wallTilemap.layoutGrid.cellSize;
        int radiusX = Mathf.CeilToInt(enemyRadius / Mathf.Max(0.01f, Mathf.Abs(cellSize.x))) + 1;
        int radiusY = Mathf.CeilToInt(enemyRadius / Mathf.Max(0.01f, Mathf.Abs(cellSize.y))) + 1;
        float radiusSquared = enemyRadius * enemyRadius;
        for (int x = -radiusX; x <= radiusX; x++)
        for (int y = -radiusY; y <= radiusY; y++)
        {
            Vector3Int wallCell = cell + new Vector3Int(x, y, 0);
            if (!wallTilemap.HasTile(wallCell)) continue;
            Bounds bounds = new Bounds(wallTilemap.GetCellCenterWorld(wallCell), cellSize);
            float nearestX = Mathf.Clamp(center.x, bounds.min.x, bounds.max.x);
            float nearestY = Mathf.Clamp(center.y, bounds.min.y, bounds.max.y);
            if (((Vector2)center - new Vector2(nearestX, nearestY)).sqrMagnitude < radiusSquared)
                return false;
        }
        return true;
    }

    private static int Manhattan(Vector3Int a, Vector3Int b)
    {
        return Mathf.Abs(a.x - b.x) + Mathf.Abs(a.y - b.y);
    }
}
