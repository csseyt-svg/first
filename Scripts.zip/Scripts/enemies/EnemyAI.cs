using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class EnemyAI : MonoBehaviour
{
    [Header("Movement Settings")]
    [SerializeField] private float moveSpeed = 3f;
    [SerializeField] private float targetReachDistance = 0.2f;
    [SerializeField] private float stoppingDistance = 0.65f;

    [Header("Detection Settings")]
    [SerializeField] private float detectionRadius = 6f;
    [SerializeField] private LayerMask playerLayer;

    [Header("Last Known Position")]
    [SerializeField] private float searchArrivalDistance = 0.35f;

    [Header("Path Refresh Settings")]
    [Min(0.1f)] [SerializeField] private float pathUpdateInterval = 0.5f;
    [Min(0.1f)] [SerializeField] private float stuckCheckInterval = 0.75f;
    [Min(0.01f)] [SerializeField] private float stuckMovementThreshold = 0.12f;

    private Rigidbody2D rb;
    private Transform playerTransform;
    private List<Vector3> currentPath;
    private int currentPathIndex;
    private float nextPathUpdateTime;
    private float nextStuckCheckTime;
    private Vector2 previousCheckPosition;
    private Vector2 lastKnownPlayerPosition;
    private bool isPlayerDetected;
    private bool investigatingLastKnownPosition;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.gravityScale = 0f;
        rb.freezeRotation = true;
        rb.sleepMode = RigidbodySleepMode2D.NeverSleep;
    }

    private void Start()
    {
        previousCheckPosition = rb.position;
        nextPathUpdateTime = Time.time + Random.Range(0f, Mathf.Max(0.1f, pathUpdateInterval));
        nextStuckCheckTime = Time.time + stuckCheckInterval;
    }

    private void Update()
    {
        Collider2D detected = Physics2D.OverlapCircle(transform.position, detectionRadius, playerLayer);
        if (detected != null)
        {
            playerTransform = detected.transform;
            lastKnownPlayerPosition = playerTransform.position;
            if (!isPlayerDetected)
                nextPathUpdateTime = 0f;
            isPlayerDetected = true;
            investigatingLastKnownPosition = false;
        }
        else if (isPlayerDetected)
        {
            // The player disappeared. Remember the last position, not their current position.
            isPlayerDetected = false;
            playerTransform = null;
            investigatingLastKnownPosition = true;
            nextPathUpdateTime = 0f;
        }

        if (!isPlayerDetected && !investigatingLastKnownPosition)
            return;

        if (!isPlayerDetected && Vector2.Distance(rb.position, lastKnownPlayerPosition) <= searchArrivalDistance)
        {
            StopInvestigating();
            return;
        }

        if (Time.time >= nextPathUpdateTime)
        {
            nextPathUpdateTime = Time.time + Mathf.Max(0.1f, pathUpdateInterval);
            RecalculatePath();
        }
    }

    private void FixedUpdate()
    {
        if (!isPlayerDetected && !investigatingLastKnownPosition)
        {
            rb.linearVelocity = Vector2.zero;
            return;
        }

        Vector2 goal = isPlayerDetected && playerTransform != null
            ? (Vector2)playerTransform.position : lastKnownPlayerPosition;
        float stopDistance = isPlayerDetected ? stoppingDistance : searchArrivalDistance;
        if (Vector2.Distance(rb.position, goal) <= stopDistance)
        {
            rb.linearVelocity = Vector2.zero;
            if (!isPlayerDetected) StopInvestigating();
            return;
        }

        if (currentPath == null || currentPathIndex >= currentPath.Count)
        {
            rb.linearVelocity = Vector2.zero;
            return;
        }

        while (currentPathIndex < currentPath.Count &&
               Vector2.Distance(rb.position, currentPath[currentPathIndex]) <= targetReachDistance)
            currentPathIndex++;

        if (currentPathIndex >= currentPath.Count)
        {
            rb.linearVelocity = Vector2.zero;
            // If the goal was a nearby reachable tile, consider the investigation finished.
            if (!isPlayerDetected) StopInvestigating();
            return;
        }

        Vector2 direction = (Vector2)currentPath[currentPathIndex] - rb.position;
        float speed = Mathf.Min(moveSpeed, direction.magnitude / Time.fixedDeltaTime);
        rb.linearVelocity = direction.normalized * speed;

        if (Time.time >= nextStuckCheckTime)
        {
            if (Vector2.Distance(previousCheckPosition, rb.position) < stuckMovementThreshold)
                nextPathUpdateTime = 0f;
            previousCheckPosition = rb.position;
            nextStuckCheckTime = Time.time + Mathf.Max(0.1f, stuckCheckInterval);
        }
    }

    private void RecalculatePath()
    {
        if (GridPathfinding.Instance == null)
        {
            currentPath = null;
            currentPathIndex = 0;
            return;
        }

        Vector2 goal = isPlayerDetected && playerTransform != null
            ? (Vector2)playerTransform.position : lastKnownPlayerPosition;
        List<Vector3> newPath = GridPathfinding.Instance.FindPath(rb.position, goal);
        if (newPath == null)
        {
            currentPath = null;
            currentPathIndex = 0;
            return;
        }

        int preservedIndex = -1;
        if (currentPath != null && currentPathIndex < currentPath.Count)
        {
            Vector3 oldWaypoint = currentPath[currentPathIndex];
            for (int i = 0; i < newPath.Count; i++)
            {
                if (Vector2.Distance(oldWaypoint, newPath[i]) < 0.05f)
                {
                    preservedIndex = i;
                    break;
                }
            }
        }
        currentPath = newPath;
        currentPathIndex = preservedIndex >= 0 ? preservedIndex : 0;
        while (currentPathIndex < currentPath.Count &&
               Vector2.Distance(rb.position, currentPath[currentPathIndex]) <= targetReachDistance)
            currentPathIndex++;
    }

    private void StopInvestigating()
    {
        investigatingLastKnownPosition = false;
        currentPath = null;
        currentPathIndex = 0;
        rb.linearVelocity = Vector2.zero;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, stoppingDistance);
        if (investigatingLastKnownPosition)
        {
            Gizmos.color = Color.magenta;
            Gizmos.DrawWireSphere(lastKnownPlayerPosition, searchArrivalDistance);
        }
        if (currentPath == null) return;
        Gizmos.color = Color.cyan;
        for (int i = currentPathIndex; i < currentPath.Count; i++)
        {
            Gizmos.DrawSphere(currentPath[i], 0.12f);
            if (i + 1 < currentPath.Count)
                Gizmos.DrawLine(currentPath[i], currentPath[i + 1]);
        }
    }
}
