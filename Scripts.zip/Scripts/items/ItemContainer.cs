using System;
using System.Collections.Generic;
using UnityEngine;
[Serializable] public class ItemStack { public string id; public int count; public ItemStack(string item,int amount){id=item;count=amount;} }
[Serializable] public class ContainerSave { public string chestId; public List<ItemStack> items = new List<ItemStack>(); }
public class ItemContainer : MonoBehaviour
{
    [Min(1)] public int capacity=30;
    [SerializeField] private List<ItemStack> slots=new List<ItemStack>();
    public event Action Changed;
    public int Capacity => capacity;
    public ItemStack Get(int i) => i>=0 && i<slots.Count ? slots[i] : null;
    private void Awake(){EnsureSize();}
    public void EnsureSize(){while(slots.Count<capacity)slots.Add(new ItemStack("",0));if(slots.Count>capacity)slots.RemoveRange(capacity,slots.Count-capacity);}
    public int Count(string id){EnsureSize();int n=0;foreach(var s in slots)if(s.id==id)n+=s.count;return n;}
    public int SpaceFor(string id){EnsureSize();if(!ItemCatalog.Valid(id))return 0;int n=0;foreach(var s in slots)if(s.count==0||string.IsNullOrEmpty(s.id))n+=ItemCatalog.MaxStack(id);else if(s.id==id)n+=ItemCatalog.MaxStack(id)-s.count;return n;}
    // Returns leftovers. No items are silently discarded.
    public int Add(string id,int amount){EnsureSize();if(!ItemCatalog.Valid(id)||amount<=0)return amount;foreach(var s in slots){if(s.id!=id||s.count>=ItemCatalog.MaxStack(id))continue;int n=Mathf.Min(amount,ItemCatalog.MaxStack(id)-s.count);s.count+=n;amount-=n;if(amount==0){Changed?.Invoke();return 0;}}
      foreach(var s in slots){if(s.count>0)continue;int n=Mathf.Min(amount,ItemCatalog.MaxStack(id));s.id=id;s.count=n;amount-=n;if(amount==0)break;}Changed?.Invoke();return amount;}
    public bool Remove(string id,int amount){EnsureSize();if(amount<=0||Count(id)<amount)return false;foreach(var s in slots){if(s.id!=id)continue;int n=Mathf.Min(s.count,amount);s.count-=n;amount-=n;if(s.count==0)s.id="";if(amount==0)break;}Changed?.Invoke();return true;}
    public void Set(int index,string id,int count){EnsureSize();if(index<0||index>=capacity)return;slots[index]=new ItemStack(count>0?id:"",Mathf.Clamp(count,0,ItemCatalog.MaxStack(id)));Changed?.Invoke();}
    public List<ItemStack> Snapshot(){EnsureSize();var copy=new List<ItemStack>();foreach(var s in slots)copy.Add(new ItemStack(s.id,s.count));return copy;}
    public void Restore(List<ItemStack> data){EnsureSize();for(int i=0;i<capacity;i++){var s=data!=null&&i<data.Count?data[i]:null;slots[i]=s!=null&&ItemCatalog.Valid(s.id)?new ItemStack(s.id,Mathf.Clamp(s.count,0,ItemCatalog.MaxStack(s.id))):new ItemStack("",0);}Changed?.Invoke();}
    public static bool Transfer(ItemContainer from,int a,ItemContainer to,int b){if(from==null||to==null)return false;from.EnsureSize();to.EnsureSize();if(a<0||a>=from.capacity||b<0||b>=to.capacity)return false;var x=from.slots[a];var y=to.slots[b];if(x.count<=0)return false;
      if(from==to&&a==b)return false;
      if(y.count==0){to.slots[b]=new ItemStack(x.id,x.count);from.slots[a]=new ItemStack("",0);}
      else if(x.id==y.id){int n=Mathf.Min(x.count,ItemCatalog.MaxStack(y.id)-y.count);if(n<=0)return false;y.count+=n;x.count-=n;if(x.count==0)from.slots[a]=new ItemStack("",0);}
      else {from.slots[a]=new ItemStack(y.id,y.count);to.slots[b]=new ItemStack(x.id,x.count);}
      from.Changed?.Invoke();if(to!=from)to.Changed?.Invoke();return true;}
}
