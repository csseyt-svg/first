using UnityEngine;
public static class ItemCatalog
{
    public const string Dirt="dirt", Stone="stone", Copper="copper", Iron="iron", Wood="wood", Gem="gem", Pickaxe="pickaxe", Sword="sword", Chest="chest";
    public static int MaxStack(string id) => id == Pickaxe || id == Sword ? 1 : 99;
    public static string DisplayName(string id) => string.IsNullOrEmpty(id) ? "Empty" : char.ToUpper(id[0]) + id.Substring(1);
    public static bool Valid(string id) => id==Dirt || id==Stone || id==Copper || id==Iron || id==Wood || id==Gem || id==Pickaxe || id==Sword || id==Chest;
}
