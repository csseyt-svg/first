using UnityEngine;
[RequireComponent(typeof(ItemContainer))]
public class StorageChest : MonoBehaviour
{
    [Tooltip("Unique, permanent ID for this chest, e.g. cave_chest_01. Never reuse IDs.")]
    public string chestId="chest_01";
    public ItemContainer Container=>GetComponent<ItemContainer>();
    private void Awake(){Container.capacity=20;Container.EnsureSize();}
}
