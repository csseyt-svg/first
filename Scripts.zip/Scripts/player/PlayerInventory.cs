using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(ItemContainer))]
public class PlayerInventory : MonoBehaviour
{
    private ItemContainer container;
    public ItemContainer Container { get { if(container==null)container=GetComponent<ItemContainer>();return container; } }
    public int Copper => Container.Count(ItemCatalog.Copper);
    public bool HasPickaxe => Container.Count(ItemCatalog.Pickaxe)>0;
    public int AddItem(string id,int amount){int leftover=Container.Add(id,amount);if(leftover>0)Debug.LogWarning("Inventory full: "+leftover+" "+id+" not collected");return leftover;}
    public void AddCopper(int amount){AddItem(ItemCatalog.Copper,amount);}
    public bool SpendCopper(int amount){return Container.Remove(ItemCatalog.Copper,amount);}
    public void GivePickaxe(){AddItem(ItemCatalog.Pickaxe,1);}
    public void RemovePickaxe(){Container.Remove(ItemCatalog.Pickaxe,1);}
    public List<ItemStack> SaveItems()=>Container.Snapshot();
    public void RestoreItems(List<ItemStack> items)=>Container.Restore(items);
    // Compatibility with saves made before the slot-based inventory.
    public void RestoreInventory(int copper,bool pickaxe){Container.Restore(null);if(copper>0)Container.Add(ItemCatalog.Copper,copper);if(pickaxe)Container.Add(ItemCatalog.Pickaxe,1);}
}
