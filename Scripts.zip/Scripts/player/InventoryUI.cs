using UnityEngine;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif
public class InventoryUI : MonoBehaviour
{
    [SerializeField] private PlayerInventory player;
    [SerializeField] private GameObject inventoryPanel;
    [SerializeField] private GameObject chestPanel;
    [SerializeField] private InventorySlotUI[] inventorySlots=new InventorySlotUI[30];
    [SerializeField] private InventorySlotUI[] chestSlots=new InventorySlotUI[20];
    [SerializeField] private Text selectedHotbarLabel;
    [SerializeField] private float chestOpenDistance=2.5f;
    private StorageChest activeChest;
    private int hotbarIndex;
    public static InventoryUI Instance {get;private set;}
    private void Awake(){Instance=this;if(player==null)player=FindObjectOfType<PlayerInventory>();if(inventoryPanel!=null)inventoryPanel.SetActive(false);if(chestPanel!=null)chestPanel.SetActive(false);}
    private void Start(){Bind();Refresh();}
    private void OnDestroy(){if(Instance==this)Instance=null;}
    private void Update(){bool tab=false,e=false;
#if ENABLE_INPUT_SYSTEM
      if(Keyboard.current!=null){tab=Keyboard.current.tabKey.wasPressedThisFrame;e=Keyboard.current.eKey.wasPressedThisFrame;for(int i=0;i<5;i++)if(Keyboard.current[(Key)((int)Key.Digit1+i)].wasPressedThisFrame)hotbarIndex=i;}
#else
      tab=Input.GetKeyDown(KeyCode.Tab);e=Input.GetKeyDown(KeyCode.E);for(int i=0;i<5;i++)if(Input.GetKeyDown(KeyCode.Alpha1+i))hotbarIndex=i;
#endif
      if(tab)ToggleInventory();if(e)TryOpenNearestChest();
      if(activeChest!=null&&player!=null&&Vector2.Distance(player.transform.position,activeChest.transform.position)>chestOpenDistance)CloseChest();
      if(selectedHotbarLabel!=null&&player!=null){var item=player.Container.Get(hotbarIndex);selectedHotbarLabel.text="Hotbar "+(hotbarIndex+1)+": "+(item!=null&&item.count>0?ItemCatalog.DisplayName(item.id):"Empty");}
    }
    private void Bind(){if(player==null)return;player.Container.Changed+=Refresh;for(int i=0;i<inventorySlots.Length;i++)if(inventorySlots[i]!=null)inventorySlots[i].Configure(player.Container,i);}
    public void ToggleInventory(){if(inventoryPanel!=null)inventoryPanel.SetActive(!inventoryPanel.activeSelf);if(inventoryPanel!=null&&!inventoryPanel.activeSelf)CloseChest();}
    private void TryOpenNearestChest(){if(player==null)return;if(activeChest!=null){CloseChest();return;}StorageChest best=null;float nearest=chestOpenDistance;foreach(var chest in FindObjectsOfType<StorageChest>()){float d=Vector2.Distance(player.transform.position,chest.transform.position);if(d<nearest){best=chest;nearest=d;}}if(best==null)return;activeChest=best;if(inventoryPanel!=null)inventoryPanel.SetActive(true);if(chestPanel!=null)chestPanel.SetActive(true);for(int i=0;i<chestSlots.Length;i++)if(chestSlots[i]!=null)chestSlots[i].Configure(best.Container,i);best.Container.Changed+=Refresh;Refresh();}
    public void CloseChest(){if(activeChest!=null)activeChest.Container.Changed-=Refresh;activeChest=null;if(chestPanel!=null)chestPanel.SetActive(false);}
    public void Refresh(){foreach(var slot in inventorySlots)if(slot!=null)slot.Refresh();foreach(var slot in chestSlots)if(slot!=null)slot.Refresh();}
}
