using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;       // Drag your Player object here in the Inspector
    public float smoothSpeed = 5f; // Adjust this to make the camera tracking tighter or looser
    public Vector3 offset = new Vector3(0, 0, -10); // Keeps the camera pulled back on the Z-axis

    void LateUpdate()
    {
        if (target != null)
        {
            // Calculate the perfect destination position
            Vector3 desiredPosition = target.position + offset;
            
            // Smoothly slide from the camera's current position toward the player's position
            Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed * Time.deltaTime);
            
            // Apply the new position to the camera
            transform.position = smoothedPosition;
        }
    }
}
