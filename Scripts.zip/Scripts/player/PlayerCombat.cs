using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

public class PlayerCombat : MonoBehaviour
{
    [Header("Attack")]
    [Min(1)] public int attackDamage = 1;
    [Min(0.1f)] public float attackRange = 1.8f;
    [Min(0.05f)] public float attackCooldown = 0.35f;
    [Min(0.05f)] public float hitRadius = 0.45f;

    [Header("References")]
    public Camera playerCamera;
    public LayerMask enemyLayers;

    private float nextAttackTime;

    private void Awake()
    {
        if (playerCamera == null) playerCamera = Camera.main;
    }

    private void Update()
    {
        if (RightMousePressed()) Attack();
    }

    private bool RightMousePressed()
    {
#if ENABLE_INPUT_SYSTEM
        return Mouse.current != null && Mouse.current.rightButton.wasPressedThisFrame;
#elif ENABLE_LEGACY_INPUT_MANAGER
        return Input.GetMouseButtonDown(1);
#else
        return false;
#endif
    }

    public void Attack()
    {
        if (Time.time < nextAttackTime || playerCamera == null) return;
        nextAttackTime = Time.time + attackCooldown;

        Vector2 origin = transform.position;
        Vector2 mouseScreen = GetMousePosition();
        float cameraDistance = Mathf.Abs(transform.position.z - playerCamera.transform.position.z);
        Vector3 mouseWorld = playerCamera.ScreenToWorldPoint(
            new Vector3(mouseScreen.x, mouseScreen.y, cameraDistance));
        Vector2 direction = (Vector2)mouseWorld - origin;
        if (direction.sqrMagnitude < 0.0001f) direction = Vector2.right;
        direction.Normalize();

        // Hit enemies near the cursor-facing end of the melee swing.
        Vector2 hitCenter = origin + direction * Mathf.Max(0f, attackRange - hitRadius);
        Collider2D[] hits = Physics2D.OverlapCircleAll(hitCenter, hitRadius, enemyLayers);

        foreach (Collider2D hit in hits)
        {
            EnemyHealth enemy = hit.GetComponentInParent<EnemyHealth>();
            if (enemy == null) continue;

            Vector2 closestPoint = hit.ClosestPoint(origin);
            if (Vector2.Distance(origin, closestPoint) > attackRange) continue;

            enemy.TakeDamage(attackDamage);
        }
    }

    private Vector2 GetMousePosition()
    {
#if ENABLE_INPUT_SYSTEM
        return Mouse.current != null ? Mouse.current.position.ReadValue() : Vector2.zero;
#elif ENABLE_LEGACY_INPUT_MANAGER
        return Input.mousePosition;
#else
        return Vector2.zero;
#endif
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, attackRange);
    }
}
