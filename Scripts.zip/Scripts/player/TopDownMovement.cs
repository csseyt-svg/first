
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;

public class TopDownMovement : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 5f;
    public float playerRadius = 0.4f;

    [Header("Tilemap Collision")]
    public Tilemap wallTilemap;

    private Vector2 moveInput;

    void Start()
    {
        if (wallTilemap == null)
        {
            GameObject wallObj = GameObject.Find("Wall_Tilemap");

            if (wallObj == null)
                wallObj = GameObject.FindWithTag("Obstacles");

            if (wallObj != null)
                wallTilemap = wallObj.GetComponent<Tilemap>();
        }

        if (wallTilemap == null)
            Debug.LogError("Wall Tilemap is missing!");
    }

    void Update()
    {
        Vector2 input = Vector2.zero;

        if (Keyboard.current != null)
        {
            if (Keyboard.current.wKey.isPressed ||
                Keyboard.current.upArrowKey.isPressed)
                input.y += 1;

            if (Keyboard.current.sKey.isPressed ||
                Keyboard.current.downArrowKey.isPressed)
                input.y -= 1;

            if (Keyboard.current.aKey.isPressed ||
                Keyboard.current.leftArrowKey.isPressed)
                input.x -= 1;

            if (Keyboard.current.dKey.isPressed ||
                Keyboard.current.rightArrowKey.isPressed)
                input.x += 1;
        }

        moveInput = input.normalized;

        MovePlayer();
    }

    void MovePlayer()
    {
        Vector2 movement = moveInput * moveSpeed * Time.deltaTime;

        // Horizontal movement
        Vector3 horizontalPosition =
            transform.position + new Vector3(movement.x, 0, 0);

        if (CanMoveTo(horizontalPosition))
        {
            transform.position = horizontalPosition;
        }

        // Vertical movement
        Vector3 verticalPosition =
            transform.position + new Vector3(0, movement.y, 0);

        if (CanMoveTo(verticalPosition))
        {
            transform.position = verticalPosition;
        }
    }

    bool CanMoveTo(Vector3 position)
    {
        if (wallTilemap == null)
            return false;

        Vector3Int centerCell =
            wallTilemap.WorldToCell(position);

        for (int x = -1; x <= 1; x++)
        {
            for (int y = -1; y <= 1; y++)
            {
                Vector3Int cell = centerCell +
                    new Vector3Int(x, y, 0);

                if (!wallTilemap.HasTile(cell))
                    continue;

                Vector3 cellCenter =
                    wallTilemap.GetCellCenterWorld(cell);

                Vector3 cellSize =
                    wallTilemap.CellToWorld(cell +
                    new Vector3Int(1, 1, 0)) -
                    wallTilemap.CellToWorld(cell);

                Bounds tileBounds = new Bounds(
                    cellCenter,
                    new Vector3(
                        Mathf.Abs(cellSize.x),
                        Mathf.Abs(cellSize.y),
                        0.1f
                    )
                );

                float closestX = Mathf.Clamp(
                    position.x,
                    tileBounds.min.x,
                    tileBounds.max.x
                );

                float closestY = Mathf.Clamp(
                    position.y,
                    tileBounds.min.y,
                    tileBounds.max.y
                );

                float distance = Vector2.Distance(
                    new Vector2(position.x, position.y),
                    new Vector2(closestX, closestY)
                );

                if (distance < playerRadius)
                    return false;
            }
        }

        return true;
    }
}
