using UnityEngine;
public class CraftingSystem : MonoBehaviour
{
    [SerializeField] private PlayerInventory player;
    private void Awake(){if(player==null)player=GetComponent<PlayerInventory>();}
    // Assign these methods to UI buttons. Recipes can be tuned here.
    public void CraftPickaxe(){Craft(ItemCatalog.Pickaxe,ItemCatalog.Copper,5,ItemCatalog.Wood,3);}
    public void CraftSword(){Craft(ItemCatalog.Sword,ItemCatalog.Iron,5,ItemCatalog.Wood,2);}
    public void CraftChest(){Craft(ItemCatalog.Chest,ItemCatalog.Wood,8,ItemCatalog.Stone,4);}
    private void Craft(string result,string a,int aCount,string b,int bCount){if(player==null)return;var bag=player.Container;
      if(bag.Count(a)<aCount||bag.Count(b)<bCount){Debug.Log("Not enough materials for "+result);return;}
      // Temporarily remove materials to check if output can fit, then restore if not.
      var backup=bag.Snapshot();bag.Remove(a,aCount);bag.Remove(b,bCount);
      if(bag.Add(result,1)>0){bag.Restore(backup);Debug.Log("No space for crafted item");return;}
      Debug.Log("Crafted "+result);
    }
}
