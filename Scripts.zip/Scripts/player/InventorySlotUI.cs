using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
// Drag a slot onto another slot to move, merge, or swap stacks.
public class InventorySlotUI : MonoBehaviour, IBeginDragHandler, IEndDragHandler, IDropHandler
{
    [SerializeField] private Text itemLabel;
    [SerializeField] private Image background;
    private ItemContainer owner;private int index;
    private static InventorySlotUI dragged;
    public void Configure(ItemContainer container,int slotIndex){owner=container;index=slotIndex;Refresh();}
    public void Refresh(){if(itemLabel==null||owner==null)return;var s=owner.Get(index);itemLabel.text=s==null||s.count<=0?"":ItemCatalog.DisplayName(s.id)+"\n"+s.count;}
    public void OnBeginDrag(PointerEventData eventData){if(owner!=null&&owner.Get(index)!=null&&owner.Get(index).count>0)dragged=this;}
    public void OnEndDrag(PointerEventData eventData){if(dragged==this)dragged=null;}
    public void OnDrop(PointerEventData eventData){if(dragged==null||owner==null)return;ItemContainer.Transfer(dragged.owner,dragged.index,owner,index);if(InventoryUI.Instance!=null)InventoryUI.Instance.Refresh();dragged=null;}
}
