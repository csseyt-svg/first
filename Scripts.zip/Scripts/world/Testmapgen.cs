using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

public class Testmapgen : MonoBehaviour
{
    [Header("Target Map Layers")]
    public Tilemap floorTilemap;
    public Tilemap wallTilemap;

    [Header("Dirt Biome Assets")]
    public TileBase dirtWallTile;
    public TileBase copperOreTile;
    public TileBase dirtFloorTile;

    [Header("Stone Biome Assets")]
    public TileBase stoneWallTile;
    public TileBase ironOreTile;
    public TileBase stoneFloorTile;

    [Header("Biome Settings")]
    public float stoneBiomeRadius = 35f;

    [Header("World Settings")]
    public int worldSeed = 12345;

    [Header("Vision Settings")]
    [Range(1f, 20f)]
    public float playerVisionRadius = 6f;

    [Header("Fog of War")]
    [Range(0f, 1f)]
    public float exploredBrightness = 0.3f;

    private Color visibleColor = Color.white;
    private Color exploredColor;

    private HashSet<Vector3Int> visibleTiles = new HashSet<Vector3Int>();
    private HashSet<Vector3Int> exploredTiles = new HashSet<Vector3Int>();

    [Header("Enemy Spawning")]
    public GameObject enemyPrefab;

    [Range(0f, 0.05f)]
    public float enemySpawnChance = 0.02f;

    [Header("Enemy Safety Limits")]
    public float minEnemySpawnRadius = 10f;

    private Transform enemyContainer;

    [Header("Player Tracking")]
    public Transform playerTransform;

    [Header("Mining")]
    public PlayerInventory playerInventory;
    public Camera miningCamera;
    [Min(0.5f)]
    public float miningRange = 2f;

    private const float MINING_RANGE_PADDING = 0.05f;

    [Header("Infinite Generation")]
    public int renderChunkRadius = 3;

    private const int CHUNK_SIZE = 16;

    [Header("Cave Shape Settings")]
    [Range(0.01f, 0.25f)]
    public float caveTunnelSize = 0.08f;

    [Range(0.3f, 0.6f)]
    public float wallDensity = 0.48f;

    [Header("Ore Vein Settings")]
    [Range(1, 8)]
    public int maximumOreVeinSize = 8;

    [Range(0.01f, 0.5f)]
    public float oreVeinFrequency = 0.12f;

    private float noiseOffsetUX;
    private float noiseOffsetUY;
    private float oreOffsetUX;
    private float oreOffsetUY;

    private HashSet<Vector2Int> generatedChunks = new HashSet<Vector2Int>();

    // Persistent mined blocks, including chunks not yet generated in this session.
    private HashSet<Vector3Int> minedCells = new HashSet<Vector3Int>();

    public List<SavedCell> GetMinedCells()
    {
        List<SavedCell> result = new List<SavedCell>();
        foreach (Vector3Int cell in minedCells)
            result.Add(new SavedCell { x = cell.x, y = cell.y });
        return result;
    }

    public void LoadMinedCells(List<SavedCell> saved)
    {
        minedCells.Clear();
        if (saved == null) return;
        foreach (SavedCell cell in saved)
            minedCells.Add(new Vector3Int(cell.x, cell.y, 0));
    }


    private Vector2Int lastPlayerChunkPos =
        new Vector2Int(int.MaxValue, int.MaxValue);

    private static readonly int[,] Octants =
    {
        { 1, 0, 0, 1 },
        { 0, 1, 1, 0 },
        { 0, -1, 1, 0 },
        { -1, 0, 0, 1 },
        { -1, 0, 0, -1 },
        { 0, -1, -1, 0 },
        { 0, 1, -1, 0 },
        { 1, 0, 0, -1 }
    };

    void Start()
    {
        if (floorTilemap == null || wallTilemap == null ||
            dirtWallTile == null || playerTransform == null)
        {
            Debug.LogError(
                "Assign your tilemaps, dirt wall tile, and player!"
            );
            enabled = false;
            return;
        }

        if (playerInventory == null)
            playerInventory = playerTransform.GetComponent<PlayerInventory>();

        if (miningCamera == null)
            miningCamera = Camera.main;

        if (playerInventory == null)
        {
            Debug.LogError(
                "No PlayerInventory found. Assign it or add it to the player."
            );
            enabled = false;
            return;
        }

        floorTilemap.ClearAllTiles();
        wallTilemap.ClearAllTiles();

        exploredColor = new Color(
            exploredBrightness,
            exploredBrightness,
            exploredBrightness,
            1f
        );

        GameObject containerObj = new GameObject("Spawned_Enemies");
        enemyContainer = containerObj.transform;

        System.Random random = new System.Random(worldSeed);

        noiseOffsetUX = (float)random.NextDouble() * 99999f;
        noiseOffsetUY = (float)random.NextDouble() * 99999f;
        oreOffsetUX = (float)random.NextDouble() * 99999f;
        oreOffsetUY = (float)random.NextDouble() * 99999f;

        int chunkX = Mathf.FloorToInt(
            playerTransform.position.x / CHUNK_SIZE
        );
        int chunkY = Mathf.FloorToInt(
            playerTransform.position.y / CHUNK_SIZE
        );

        lastPlayerChunkPos = new Vector2Int(chunkX, chunkY);

        UpdateInfiniteMap();
        UpdateShadowcastVision();
    }

    void Update()
    {
        if (playerTransform == null)
            return;

        int chunkX = Mathf.FloorToInt(
            playerTransform.position.x / CHUNK_SIZE
        );
        int chunkY = Mathf.FloorToInt(
            playerTransform.position.y / CHUNK_SIZE
        );

        Vector2Int currentChunk = new Vector2Int(chunkX, chunkY);

        if (currentChunk != lastPlayerChunkPos)
        {
            lastPlayerChunkPos = currentChunk;
            UpdateInfiniteMap();
        }

        HandleMiningInput();
        UpdateShadowcastVision();
    }

    // ==========================================
    // MINING
    // ==========================================

    void HandleMiningInput()
    {
        bool minePressed = false;
        Vector2 screenPosition = Vector2.zero;

#if ENABLE_INPUT_SYSTEM
        if (Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
        {
            minePressed = true;
            screenPosition = Mouse.current.position.ReadValue();
        }
#else
        if (Input.GetMouseButtonDown(0))
        {
            minePressed = true;
            screenPosition = Input.mousePosition;
        }
#endif

        if (!minePressed)
            return;

        if (miningCamera == null)
            miningCamera = Camera.main;

        if (miningCamera == null)
        {
            Debug.LogWarning("Mining needs a camera. Assign Mining Camera or tag your camera MainCamera.");
            return;
        }

        Vector3 worldPosition = miningCamera.ScreenToWorldPoint(
            new Vector3(screenPosition.x, screenPosition.y, -miningCamera.transform.position.z)
        );

        Vector3Int targetCell = wallTilemap.WorldToCell(worldPosition);
        MineTile(targetCell);
    }

    void MineTile(Vector3Int cell)
    {
        if (!wallTilemap.HasTile(cell))
            return;

        Vector3 cellCenter = wallTilemap.GetCellCenterWorld(cell);

        if (Vector2.Distance(playerTransform.position, cellCenter) >
            miningRange + MINING_RANGE_PADDING)
            return;

        if (!HasEmptyNeighbor(cell))
            return;

        TileBase minedTile = wallTilemap.GetTile(cell);

        // Dirt can be mined by hand. Every other wall/ore tile needs a pickaxe.
        if (minedTile != dirtWallTile && !playerInventory.HasPickaxe)
        {
            Debug.Log("You need a pickaxe to mine this.");
            return;
        }

        string item = minedTile == copperOreTile ? ItemCatalog.Copper
            : minedTile == ironOreTile ? ItemCatalog.Iron
            : minedTile == dirtWallTile ? ItemCatalog.Dirt
            : ItemCatalog.Stone;
        // Don't destroy the block when inventory is full.
        if (playerInventory.Container.SpaceFor(item) < 1)
        {
            Debug.Log("Inventory full; cannot mine " + item);
            return;
        }
        playerInventory.AddItem(item, 1);

        wallTilemap.SetTile(cell, null);
        minedCells.Add(cell);

        // Reveal the floor tile underneath the removed wall.
        MarkVisible(cell);
        UpdateShadowcastVision();
    }

    bool HasEmptyNeighbor(Vector3Int cell)
    {
        Vector3Int[] directions =
        {
            new Vector3Int(1, 0, 0),
            new Vector3Int(-1, 0, 0),
            new Vector3Int(0, 1, 0),
            new Vector3Int(0, -1, 0)
        };

        foreach (Vector3Int direction in directions)
        {
            if (!wallTilemap.HasTile(cell + direction))
                return true;
        }

        return false;
    }

    // ==========================================
    // GRID-BASED FOG OF WAR
    // ==========================================

    void UpdateShadowcastVision()
    {
        foreach (Vector3Int pos in visibleTiles)
        {
            if (floorTilemap.HasTile(pos))
                floorTilemap.SetColor(pos, exploredColor);

            if (wallTilemap.HasTile(pos))
                wallTilemap.SetColor(pos, exploredColor);
        }

        visibleTiles.Clear();

        Vector3Int playerCell = wallTilemap.WorldToCell(
            playerTransform.position
        );

        MarkVisible(playerCell);

        int radius = Mathf.CeilToInt(playerVisionRadius);

        for (int i = 0; i < 8; i++)
        {
            CastLight(
                playerCell.x,
                playerCell.y,
                1,
                1f,
                0f,
                Octants[i, 0],
                Octants[i, 1],
                Octants[i, 2],
                Octants[i, 3],
                radius
            );
        }
    }

    // ==========================================
    // RECURSIVE SHADOWCASTING
    // ==========================================

    void CastLight(
        int centerX,
        int centerY,
        int row,
        float startSlope,
        float endSlope,
        int xx,
        int xy,
        int yx,
        int yy,
        int radius
    )
    {
        if (startSlope < endSlope)
            return;

        float newStartSlope = startSlope;

        for (int distance = row; distance <= radius; distance++)
        {
            bool blocked = false;
            int dx = -distance - 1;
            int dy = -distance;

            while (dx <= 0)
            {
                dx++;

                int mapX = centerX + dx * xx + dy * xy;
                int mapY = centerY + dx * yx + dy * yy;

                float leftSlope = (dx - 0.5f) / (dy + 0.5f);
                float rightSlope = (dx + 0.5f) / (dy - 0.5f);

                if (startSlope < rightSlope)
                    continue;

                if (endSlope > leftSlope)
                    break;

                Vector3Int tilePosition = new Vector3Int(mapX, mapY, 0);

                if (dx * dx + dy * dy <= radius * radius)
                    MarkVisible(tilePosition);

                bool opaque = wallTilemap.HasTile(tilePosition);

                if (blocked)
                {
                    if (opaque)
                    {
                        newStartSlope = rightSlope;
                        continue;
                    }
                    else
                    {
                        blocked = false;
                        startSlope = newStartSlope;
                    }
                }
                else
                {
                    if (opaque && distance < radius)
                    {
                        blocked = true;

                        CastLight(
                            centerX,
                            centerY,
                            distance + 1,
                            startSlope,
                            leftSlope,
                            xx,
                            xy,
                            yx,
                            yy,
                            radius
                        );

                        newStartSlope = rightSlope;
                    }
                }
            }

            if (blocked)
                break;
        }
    }

    // ==========================================
    // MARK VISIBLE AND EXPLORED TILES
    // ==========================================

    void MarkVisible(Vector3Int position)
    {
        if (visibleTiles.Contains(position))
            return;

        bool hasFloor = floorTilemap.HasTile(position);
        bool hasWall = wallTilemap.HasTile(position);

        if (!hasFloor && !hasWall)
            return;

        visibleTiles.Add(position);
        exploredTiles.Add(position);

        if (hasFloor)
            floorTilemap.SetColor(position, visibleColor);

        if (hasWall)
            wallTilemap.SetColor(position, visibleColor);
    }

    // ==========================================
    // INFINITE CHUNK GENERATION
    // ==========================================

    void UpdateInfiniteMap()
    {
        int chunkX = lastPlayerChunkPos.x;
        int chunkY = lastPlayerChunkPos.y;

        bool loadedNewChunk = false;

        for (int x = -renderChunkRadius; x <= renderChunkRadius; x++)
        {
            for (int y = -renderChunkRadius; y <= renderChunkRadius; y++)
            {
                Vector2Int chunk = new Vector2Int(
                    chunkX + x,
                    chunkY + y
                );

                if (!generatedChunks.Contains(chunk))
                {
                    GenerateChunk(chunk.x, chunk.y);
                    generatedChunks.Add(chunk);
                    loadedNewChunk = true;
                }
            }
        }

        if (loadedNewChunk)
        {
            floorTilemap.RefreshAllTiles();
            wallTilemap.RefreshAllTiles();
        }
    }

    // ==========================================
    // GENERATE CHUNK
    // ==========================================

    void GenerateChunk(int chunkX, int chunkY)
    {
        int startX = chunkX * CHUNK_SIZE;
        int startY = chunkY * CHUNK_SIZE;

        System.Random chunkRandom = new System.Random(
            GetChunkSeed(chunkX, chunkY)
        );

        List<Vector3Int> enemySpawnCandidates = new List<Vector3Int>();

        for (int x = 0; x < CHUNK_SIZE; x++)
        {
            for (int y = 0; y < CHUNK_SIZE; y++)
            {
                int worldX = startX + x;
                int worldY = startY + y;

                Vector3Int pos = new Vector3Int(worldX, worldY, 0);

                float distanceFromCenter = Vector2.Distance(
                    Vector2.zero,
                    new Vector2(worldX, worldY)
                );

                bool stoneBiome = distanceFromCenter >= stoneBiomeRadius;

                TileBase floor = stoneBiome
                    ? (stoneFloorTile != null ? stoneFloorTile : dirtFloorTile)
                    : dirtFloorTile;

                if (floor != null)
                    floorTilemap.SetTile(pos, floor);

                floorTilemap.SetTileFlags(pos, TileFlags.None);
                floorTilemap.SetColor(pos, Color.clear);

                // Safe starting area.
                if (worldX >= -2 && worldX <= 2 &&
                    worldY >= -2 && worldY <= 2)
                {
                    wallTilemap.SetTile(pos, null);
                    continue;
                }

                float largeNoise = Mathf.PerlinNoise(
                    worldX * caveTunnelSize + noiseOffsetUX,
                    worldY * caveTunnelSize + noiseOffsetUY
                );

                float detailNoise = Mathf.PerlinNoise(
                    worldX * caveTunnelSize * 2.5f + oreOffsetUX,
                    worldY * caveTunnelSize * 2.5f + oreOffsetUY
                );

                float combinedNoise = largeNoise * 0.75f + detailNoise * 0.25f;
                bool isWall = combinedNoise < wallDensity;

                if (isWall)
                {
                    TileBase wall = stoneBiome
                        ? (stoneWallTile != null ? stoneWallTile : dirtWallTile)
                        : dirtWallTile;

                    wallTilemap.SetTile(pos, wall);
                    wallTilemap.SetTileFlags(pos, TileFlags.None);
                    wallTilemap.SetColor(pos, Color.clear);
                }
                else
                {
                    wallTilemap.SetTile(pos, null);
                }

                // Enemy spawning.
                if (!isWall &&
                    distanceFromCenter >= minEnemySpawnRadius &&
                    enemyPrefab != null)
                {
                    float spawnValue = Mathf.PerlinNoise(
                        worldX * 0.37f + noiseOffsetUX,
                        worldY * 0.37f + noiseOffsetUY
                    );

                    if (spawnValue < enemySpawnChance)
                    {
                        // Spawn only after the entire chunk and ore veins are generated.
                        enemySpawnCandidates.Add(pos);
                    }
                }
            }
        }

        GenerateOreVeins(startX, startY, chunkRandom);

        // Apply saved mining changes BEFORE checking enemy spawn locations.
        for (int x = 0; x < CHUNK_SIZE; x++)
        {
            for (int y = 0; y < CHUNK_SIZE; y++)
            {
                Vector3Int cell = new Vector3Int(startX + x, startY + y, 0);
                if (minedCells.Contains(cell)) wallTilemap.SetTile(cell, null);
            }
        }

        foreach (Vector3Int spawnCell in enemySpawnCandidates)
        {
            if (!IsSafeEnemySpawnCell(spawnCell))
                continue;

            Vector3 spawnPosition = wallTilemap.GetCellCenterWorld(spawnCell);
            spawnPosition.z = 0f;

            GameObject enemy = Instantiate(enemyPrefab, spawnPosition, Quaternion.identity);
            enemy.transform.SetParent(enemyContainer);
        }
    }

    // Require a 3x3 area of empty wall cells so enemies do not clip into
    // neighboring walls. Also check for already-spawned enemy colliders.
    bool IsSafeEnemySpawnCell(Vector3Int cell)
    {
        for (int dx = -1; dx <= 1; dx++)
        {
            for (int dy = -1; dy <= 1; dy++)
            {
                Vector3Int neighbor = new Vector3Int(cell.x + dx, cell.y + dy, cell.z);
                if (wallTilemap.HasTile(neighbor))
                    return false;
            }
        }

        Vector3 center = wallTilemap.GetCellCenterWorld(cell);
        // Reject occupied spots. Does not rely on the wall collider being updated yet.
        if (Physics2D.OverlapCircle(center, 0.35f) != null)
            return false;

        return true;
    }

    // ==========================================
    // ORE VEIN GENERATION
    // ==========================================

    void GenerateOreVeins(int startX, int startY, System.Random random)
    {
        int veinAttempts = Mathf.Max(
            1,
            Mathf.RoundToInt(
                CHUNK_SIZE * CHUNK_SIZE * oreVeinFrequency / 8f
            )
        );

        HashSet<Vector3Int> usedOreTiles = new HashSet<Vector3Int>();

        Vector3Int[] directions =
        {
            new Vector3Int(1, 0, 0),
            new Vector3Int(-1, 0, 0),
            new Vector3Int(0, 1, 0),
            new Vector3Int(0, -1, 0)
        };

        for (int vein = 0; vein < veinAttempts; vein++)
        {
            int veinSize = random.Next(
                1,
                Mathf.Clamp(maximumOreVeinSize, 1, 8) + 1
            );

            Vector3Int currentPos = Vector3Int.zero;
            bool foundStart = false;

            for (int attempt = 0; attempt < 40; attempt++)
            {
                int x = random.Next(0, CHUNK_SIZE);
                int y = random.Next(0, CHUNK_SIZE);

                Vector3Int candidate = new Vector3Int(
                    startX + x,
                    startY + y,
                    0
                );

                if (wallTilemap.HasTile(candidate) &&
                    !usedOreTiles.Contains(candidate))
                {
                    currentPos = candidate;
                    foundStart = true;
                    break;
                }
            }

            if (!foundStart)
                continue;

            bool startingBiomeIsStone = Vector2.Distance(
                Vector2.zero,
                new Vector2(currentPos.x, currentPos.y)
            ) >= stoneBiomeRadius;

            TileBase oreTile = startingBiomeIsStone
                ? ironOreTile
                : copperOreTile;

            if (oreTile == null)
                continue;

            for (int i = 0; i < veinSize; i++)
            {
                if (!wallTilemap.HasTile(currentPos) ||
                    usedOreTiles.Contains(currentPos))
                    break;

                bool currentBiomeIsStone = Vector2.Distance(
                    Vector2.zero,
                    new Vector2(currentPos.x, currentPos.y)
                ) >= stoneBiomeRadius;

                if (currentBiomeIsStone != startingBiomeIsStone)
                    break;

                wallTilemap.SetTile(currentPos, oreTile);
                wallTilemap.SetTileFlags(currentPos, TileFlags.None);
                wallTilemap.SetColor(currentPos, Color.clear);
                usedOreTiles.Add(currentPos);

                List<Vector3Int> availableDirections = new List<Vector3Int>();

                foreach (Vector3Int direction in directions)
                {
                    Vector3Int nextPos = currentPos + direction;

                    bool insideChunk =
                        nextPos.x >= startX &&
                        nextPos.x < startX + CHUNK_SIZE &&
                        nextPos.y >= startY &&
                        nextPos.y < startY + CHUNK_SIZE;

                    if (insideChunk &&
                        wallTilemap.HasTile(nextPos) &&
                        !usedOreTiles.Contains(nextPos))
                    {
                        availableDirections.Add(direction);
                    }
                }

                if (availableDirections.Count == 0)
                    break;

                currentPos += availableDirections[
                    random.Next(availableDirections.Count)
                ];
            }
        }
    }

    // ==========================================
    // CHUNK SEED
    // ==========================================

    int GetChunkSeed(int chunkX, int chunkY)
    {
        unchecked
        {
            int seed = worldSeed;
            seed ^= chunkX * 73856093;
            seed ^= chunkY * 19349663;
            return seed;
        }
    }
}
